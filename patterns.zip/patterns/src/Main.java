import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        bmicalculator();
    }

public static void bmicalculator(){

        int Age;
        double Height, Weight, BMI;
        String Gender;

        Scanner input = new Scanner(System.in);
        System.out.println("BMI Calculator");

        System.out.println("Enter the Gender :");
        Gender = input.nextLine();

        System.out.println("Enter the Age :");
        Age = input.nextInt();

        System.out.println("Enter the Height :");
        Height = input.nextDouble();

        System.out.println("Enter the Weight :");
        Weight = input.nextDouble();

        BMI = Weight / (Height * Height);

        System.out.println("The result is " + BMI);
    }
}













